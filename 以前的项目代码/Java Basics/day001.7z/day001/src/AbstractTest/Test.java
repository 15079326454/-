package AbstractTest;

public  class Test {
    public static void main(String[] args) {
        CommonEmployee c = new CommonEmployee();
        c.work();
        c.setCommonEmployeeInfo(1,"zhang",2333);
        c.getCommonEmployeeInfo();
    }



}
