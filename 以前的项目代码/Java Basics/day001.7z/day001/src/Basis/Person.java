package Basis;

public class Person {
    int name;
    int age;
public  void  getInfo(){
    System.out.println("Person类的getInfo方法被调用了");
}

}
