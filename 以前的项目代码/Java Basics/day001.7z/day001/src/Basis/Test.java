package Basis;

public class Test {
    public static void main(String[] args) {
MyDate m1 = new MyDate(2030,11,23);
MyDate m2 = new MyDate(2030,1,23);
        System.out.println(m1.equals(m2));


    }
}





