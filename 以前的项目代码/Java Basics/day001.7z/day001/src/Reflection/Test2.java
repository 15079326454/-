package Reflection;

import java.lang.reflect.Constructor;

public class Test2 {
    public static void main(String[] args) {
        try {
//            通过包名.类名的字符串，调用Class.forName方法获取指定类的Class实例
            Class clazz = Class.forName("Reflection.Students");
            Class superClazz = clazz.getSuperclass();//获取父类
            System.out.println("父类是：" + superClazz.getName());
            Class[] interfaces = clazz.getInterfaces();//获取当前所有接口
            for (Class c : interfaces) {
                System.out.println("接口是：" + c.getName());
            }

            Constructor[] cons = clazz.getConstructors();//获取到类的公有的构造方法
            for (Constructor c : cons){
//                getName();------取得方法名称
                System.out.println("构造方法名称：" + c.getName());
//                getModifiers();-----取得修饰符。返回参数1：代表是public
                System.out.println("构造方法名称：" + c.getName()+"修饰符是：" + c.getModifiers());

                Class[] paramClazz = c.getParameterTypes();
                for (Class pc:paramClazz){
                    System.out.println("构造方法名称：" +c.getName()+"的参数类型是：" +pc.getName());
                }
            }

            Constructor[] cos1 =clazz.getDeclaredConstructors();//获取类的所有构造方法，包括私有的。

            for (Constructor c : cos1){
//                getName();------取得方法名称
                System.out.println("构造方法名称：" + c.getName());
//                getModifiers();-----取得修饰符，返回参数2：代表是private
                System.out.println("构造方法名称：" + c.getName()+"修饰符是：" + c.getModifiers());
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

class Students extends Persion implements Move, Study {
    String school;

    public Students() {
    }

    public Students(String school) {
        this.school = school;
    }
    private Students(String name ,int age){
        this.name=name;
        this.age=age;
    }
    public void showInfo() {
        System.out.println("学校是：" + this.school);
    }

    @Override
    public void moveType() {
        System.out.println("学习的中学知识");
    }

    @Override
    public void studyInfo() {
        System.out.println("骑自行车上学");
    }
}

interface Move {
    void moveType();
}

interface Study {
    void studyInfo();
}
