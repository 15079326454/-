package Reflection;

public class Persion {
    public String name;
     int age;
}
