INSERT INTO `student`(`id`, `name`, `tId`) VALUES (1, '小明', 1);
INSERT INTO `student`(`id`, `name`, `tId`) VALUES (2, '小红', 1);
INSERT INTO `student`(`id`, `name`, `tId`) VALUES (3, '小张', 1);
INSERT INTO `student`(`id`, `name`, `tId`) VALUES (4, '小李', 1);
INSERT INTO `student`(`id`, `name`, `tId`) VALUES (5, '小王', 1);
INSERT INTO `student`(`id`, `name`, `tId`) VALUES (6, '小乐', 1);
