package com.zlq.entity;

import lombok.Data;

@Data
public class Teacher {
    private int id;
    private String name;
}
