INSERT INTO `teacher`(`id`, `name`) VALUES (1, '张老师');
