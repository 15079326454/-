create definer = root@localhost view myview as
select `bjpowernode`.`emp`.`EMPNO` AS `empno`, `bjpowernode`.`emp`.`ENAME` AS `ename`
from `bjpowernode`.`emp`;

