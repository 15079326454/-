create definer = root@localhost view myviewl as
select `bjpowernode`.`emp_bak`.`EMPNO` AS `empno`,
       `bjpowernode`.`emp_bak`.`ENAME` AS `ename`,
       `bjpowernode`.`emp_bak`.`SAL`   AS `sal`
from `bjpowernode`.`emp_bak`;

