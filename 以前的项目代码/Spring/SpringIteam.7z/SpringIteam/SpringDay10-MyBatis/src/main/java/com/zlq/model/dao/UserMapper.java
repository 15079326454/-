package com.zlq.model.dao;

import com.zlq.model.entity.User;

import java.util.List;

public interface UserMapper {
    public List<User> selectUser();
}
