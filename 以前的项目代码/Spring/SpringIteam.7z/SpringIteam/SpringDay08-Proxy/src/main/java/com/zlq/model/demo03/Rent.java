package com.zlq.model.demo03;
//租房
public interface Rent {
    public  void rent();
}
