package com.zlq.model.service;

public interface UserService {
    void getUser();

}
