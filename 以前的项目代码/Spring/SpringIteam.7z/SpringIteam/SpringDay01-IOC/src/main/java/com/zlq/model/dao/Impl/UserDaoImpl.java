package com.zlq.model.dao.Impl;

import com.zlq.model.dao.UserDao;

public class UserDaoImpl implements UserDao {
    @Override
    public void getUser() {
        System.err.println("默认获取用户数据");
    }
}
