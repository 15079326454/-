package com.zlq.model.dao;

public interface UserDao {
    void getUser();
}
