package com.zlq.model.entity;

public class Cat {
  public void shout(){
      System.out.println("喵喵~小猫");
  }
}
