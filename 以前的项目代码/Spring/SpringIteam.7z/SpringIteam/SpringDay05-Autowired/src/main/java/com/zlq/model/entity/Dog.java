package com.zlq.model.entity;

public class Dog {
    public void shout(){
        System.out.println("汪汪~小狗");
    }
}
