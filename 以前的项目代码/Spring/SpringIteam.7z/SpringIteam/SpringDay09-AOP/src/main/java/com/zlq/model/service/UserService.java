package com.zlq.model.service;

public interface UserService {
    public void add();
    public void delete();
    public void update();
    public void select();
}
