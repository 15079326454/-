package com.zlq.config;

public class UserConfig2 {
}
